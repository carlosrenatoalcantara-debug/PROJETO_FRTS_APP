/**
 * overrides.js — Edições manuais sobre o layout do Engine.
 *
 * Decisão de arquitetura: coordenadas absolutas NÃO são a verdade do projeto.
 * A verdade do layout é sempre o Engine; o usuário pode mover componentes e essas
 * edições ficam como `overrides` (por id). Quando o projeto muda eletricamente, o
 * Engine recalcula a base e os overrides de componentes que deixaram de existir são
 * podados (não há layout antigo inconsistente com o projeto).
 *
 * override por id: { position?: {x,y}, ... }
 */

import { clampNoDiagramBox } from './geometry.js'

/**
 * Aplica overrides sobre o layout base (posição manual vence a calculada).
 * BUG-014: a posição manual é CLAMPADA ao DIAGRAM_BOX — arrastar no editor nunca
 * coloca um componente fora do box; SVG, PDF e Editor usam a mesma geometria contida.
 * BUG-021: `dimsById` (id → {w,h} reais) permite clampar pelo tamanho REAL do símbolo —
 * componentes baixos (aterramento) podem descer mais sem serem travados pela altura
 * nominal (H=90).
 */
export function aplicarOverrides(layoutBase = {}, overrides = {}, dimsById = {}) {
  const out = {}
  for (const [id, pos] of Object.entries(layoutBase)) {
    const ov = overrides?.[id]
    const d = dimsById[id]
    out[id] = ov?.position ? clampNoDiagramBox(ov.position.x, ov.position.y, d?.w, d?.h) : { ...pos }
  }
  return out
}

/**
 * Remove overrides cujos ids não existem mais entre os componentes atuais.
 * @returns {{ overrides: object, removidos: string[] }}
 */
export function podarOverridesOrfaos(overrides = {}, components = []) {
  const idsValidos = new Set(components.map(c => c.id))
  const limpos = {}
  const removidos = []
  for (const [id, ov] of Object.entries(overrides || {})) {
    if (idsValidos.has(id)) limpos[id] = ov
    else removidos.push(id)
  }
  return { overrides: limpos, removidos }
}
